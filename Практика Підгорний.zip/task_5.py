# 14.1 корд малий. = 3.624 куб. м = 128 куб. футів;

from prettytable import PrettyTable

table = PrettyTable()
table.field_names = ["корд малий", "куб. м", "куб. фут"]

first_value = float(input("Початкове число  "))
amount = int(input("Кількість строк таблиці  "))
step = float(input("Крок зміни  "))

value = first_value
while value < (amount*step)+first_value:
    table.add_row([round(value, 4), round(
        value*3.624, 4), round(value*128, 4)])
    value += step

print(table)
