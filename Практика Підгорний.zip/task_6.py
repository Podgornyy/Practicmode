# 14)z = ху - Pi;

from module import f_19, f_20
from math import pi

x, y = 0, 1
for k in range(1, 19):
    x += f_19(k)
    y *= f_20(k)

z = x*y - pi

print(f"x = {round(x, 3)},\ny = {round(y, 3)},\nz = {round(z, 3)}")
