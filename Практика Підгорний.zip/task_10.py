# 14.  Вивести номери і значення двох найбільших елементів.
# Обчислити їхню суму.

from module import f_24

arr = []
for x in range(1, 8):
    y = f_24(x)
    arr.append(y)
print(f"Масив: {arr}")

if len(arr) < 2:
    print("Масив не має 2 елементи")
else:
    first_max_index = arr.index(max(arr))
    first_max = arr.pop(first_max_index)
    second_max_index = arr.index(max(arr))
    second_max = arr.pop(second_max_index)
    print(f"Два найбільших елементи: \n\
        Номер - {first_max_index}, елемент - {first_max}\n\
        Номер - {second_max_index}, елемент - {second_max}\n\
Їх сума = {first_max+second_max}")
