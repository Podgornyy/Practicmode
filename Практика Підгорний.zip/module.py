# Необхідно створити бібліотеку функцій які використовуються в задачах.

from math import sin, cos


def f_16(num):
    return round(cos(2.1*num)*sin(abs(num))/0.15-5.8, 3)


def f_17(num):
    return round(abs(cos(2*num**3)+2*sin(num))+10.51*cos(abs(3*num)), 3)


def f_18(num):
    return round(abs(sin(num**2/1.5-2))+11.73*cos(abs(num/7.5)), 3)


def f_19(num):
    return round(13.4*cos(abs(num)*sin(num**2-3.1)), 3)


def f_20(num):
    return round(abs(cos(num**2-3.8))/4.5-9.7*sin(num-3.1), 3)


def f_21(num):
    return round(13.4*sin(-1.26)*cos(abs(num/7.5)), 3)


def f_22(num):
    return round(2*sin(abs(2*num))*cos(2*num)-11.6*sin(num/0.4-1), 3)


def f_23(num):
    return round(sin(abs(num))/0.1+9.4*sin(3*num-2.5), 3)


def f_24(num):
    return round(10.8*abs(cos(num**2)/1.13)*sin(num+1.4), 3)
