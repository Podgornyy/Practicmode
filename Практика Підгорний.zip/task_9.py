# 14.  Обчислити суму прибутків у границях від 170 до 620 (в у.е.). Скільки років фірма мала такий прибуток?

from module import f_23
from prettytable import PrettyTable


total = []
table = PrettyTable()
table.field_names = ['рік', 'величина доходу', 'доход/збиток']
for x in range(1991, 2002):
    y = round(100*(f_23(x)), 2)
    total.append(y)
    status = 'доход' if y >= 0 else 'збиток'
    table.add_row([x, y, status])

incomes = list(filter(lambda x: (x >= 170 and x <= 620), total))

print(f"{table}\n\n\
Суму прибутків у границях від 170 до 620 = {sum(incomes)},\n\
Такий прибуток був протягом {len(incomes)} років")
