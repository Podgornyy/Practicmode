from module import f_21
from random import randint
from math import factorial


def precision(x):
    s = str(x)
    return (abs(s.find('.') - len(s)) - 1) >= 3


k = 1
ak = f_21(k)/k
arr = [ak]
while True:
    k += 1
    ak = f_21(k)/k
    arr.append(ak)
    q = arr[-2]/arr[-1]
    summa = arr[-1]/(1-q)
    if precision(summa):
        break

print(
    f"Сума = {round(summa, 4)}\nДодатків для досягнення заданої точності = {k}")


k = 1
x = randint(1, 100)/100
ak = (-1)**k*(f_21(k)*x**k)/factorial(k)
arr = [ak]
while True:
    k += 1
    ak = (-1)**k*(f_21(k)*x**k)/factorial(k)
    arr.append(ak)
    q = arr[-2]/arr[-1]
    summa = arr[-1]/(1-q)
    if precision(summa):
        break

print(
    f"Сума = {round(summa, 4)}\nДодатків для досягнення заданої точності = {k}")
