# 3a

from module import f_16, f_17, f_18
from math import tan, log, exp


def fi(x):
    a = float(input("Введіть a  "))
    b = float(input("Введіть b  "))
    return round(tan(x+a)-log(abs(b+7), 14), 3)


def omega(x):
    c = float(input("Введіть c  "))
    d = float(input("Введіть d  "))
    return round(c*(x**2+d*exp(1.3))**0.2, 3)


x = int(input("Введіть x  "))

# а) повну форму команди розгалуження if;

if abs(x) < 10:
    print(f_16(fi(x)))
else:
    print(f_17(omega(x)))


# б) коротку форму команди розгалуження if.

print(f_16(fi(x)) if abs(x) < 10 else f_17(omega(x)))


# 3б

work_types = {"А": 10, "Б": 15, "В": 20, "error_type": 0}
work_type = input("Введіть тип роботи  ")

if work_type == "А":
    salary = 100*abs(f_16(14)+50)
elif work_type == "Б":
    salary = 150*abs(f_17(14)+100)
elif work_type == "В":
    salary = 200*abs(f_18(14)+135)
else:
    print("Неіснуюча робота, зарплата = 0")
    salary = 0
    work_type = "error_type"

tax = salary * (work_types[work_type]/100)
receive = salary-tax

print(
    f"Зарплата = {round(salary, 2)},\nПодаток = {round(tax, 2)}\nДо видачі = {round(receive, 2)}")
