# 14. Обчислити добуток негативних значень функції y. Визначити аргумент максимального значення функції.

from module import f_22
from prettytable import PrettyTable
from functools import reduce

table = PrettyTable()
table.field_names = ['x', 'y']

i = 0
arr = []
while i <= 14:
    y = f_22(i)
    arr.append(y)
    table.add_row([round(i, 1), y])
    i = i+1.4

negative_elements = list(filter(lambda x: x < 0, arr))
multiply_neg_elements = round(reduce(lambda a, b: a*b, negative_elements), 3)

print(f"{table}\n\n\
Добуток негативних значень функції y = {multiply_neg_elements},\n\
Аргумент максимального значення функції = {round(arr.index(max(arr))*1.4, 1)}")
