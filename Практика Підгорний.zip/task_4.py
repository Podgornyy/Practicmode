# 14.  Ввести телефонний код міста. Вивести назву міста.

num = input("Введіть телефонний код міста  ")


if num == "044":
    print("Kyiv")
elif num == "056":
    print("Dnipro")
elif num == "057":
    print("Kharkov")
elif num == "043":
    print("Vinnitsa")
elif num == "048":
    print("Odessa")
elif num == "061":
    print("Zaporozhe")
elif num == "031":
    print("Uzhgorod")
elif num == "041":
    print("Zhitomir")
elif num == "04463":
    print("Belaja Tserkov (Kiev)")
else:
    print("Код не знайдений")


if num == "044":
    print("Kyiv")
else:
    if num == "056":
        print("Dnipro")
    else:
        if num == "057":
            print("Kharkov")
        else:
            if num == "043":
                print("Vinnitsa")
            else:
                if num == "048":
                    print("Odessa")
                else:
                    if num == "061":
                        print("Zaporozhe")
                    else:
                        if num == "031":
                            print("Uzhgorod")
                        else:
                            if num == "041":
                                print("Zhitomir")
                            else:
                                if num == "04463":
                                    print("Belaja Tserkov (Kiev)")
                                else:
                                    print("Код не знайдений")
