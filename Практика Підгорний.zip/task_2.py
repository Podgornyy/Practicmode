# 14.  Обчислити медіану mа і радіус описаної окружності R.

def sidelength(ax, ay, bx, by):
    return ((bx-ax)**2+(by-ay)**2)**0.5


a, b, c = sidelength(0, 0, 14, 13), sidelength(
    14, 13, -14, 15), sidelength(-14, 15, 0, 0)

ma = round(0.5*(2*(b**2)+2*(c**2)-(a**2))**0.5, 4)

p = (a+b+c)/2
h = (2/a)*(p*(p-a)*(p-b)*(p-c))**0.5
S = a*h/2
R = round(a*b*c/(4*S), 5)

print(f"Медіана mа = {ma},\nРадіус описаної окружності R = {R}")
